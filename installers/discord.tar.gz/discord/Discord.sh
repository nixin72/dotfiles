#!/bin/bash
PULSE_LATENCY_MSEC=30 /opt/discord/Discord
